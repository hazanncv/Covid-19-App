import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class Home extends StatelessWidget {
  Home();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(
              height: 40,
            ),
            Text(
              "Hi, Monito",
              style: GoogleFonts.montserrat(
                fontWeight: FontWeight.w700,
                fontSize: 20,
                color: Color(0xff061035),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(20),
              child: Text(
                "Lorem Ipsumn is a simply dummy text of the printing and typesetting",
                textAlign: TextAlign.center,
                style: GoogleFonts.montserrat(
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  color: Color(0xff061035),
                ),
              ),
            ),
            Header(
              item1: "Symptoms",
              item2: "View All",
            ),
            Container(
              height: 160,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding:
                    EdgeInsets.only(left: 20, right: 20, top: 20, bottom: 20),
                children: <Widget>[
                  SymptomsCard(
                    name: "High Fever",
                    image: "assets/fever.png",
                  ),
                  SizedBox(
                    width: 30,
                  ),
                  SymptomsCard(
                    name: "Coughing",
                    image: "assets/cough.png",
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.all(20),
              child: Container(
                height: 200,
                width: 360,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  image: DecorationImage(
                    image: AssetImage("assets/mask_woman.png"),
                    fit: BoxFit.cover,
                  ),
                ),
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 200,
                      child: Text(
                        "Stay at home to",
                        style: GoogleFonts.montserrat(
                          fontWeight: FontWeight.w700,
                          fontSize: 20,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 200,
                      child: Text(
                        "Stop corona virus",
                        style: GoogleFonts.montserrat(
                          fontWeight: FontWeight.w700,
                          fontSize: 20,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    Spacer(),
                    Container(
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: Color(0xff214CC8),
                          borderRadius: BorderRadius.circular(10)),
                      child: Text(
                        "Know More",
                        style: GoogleFonts.montserrat(
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Header(
              item1: "Requirements",
              item2: "View All",
            ),
            Padding(
              padding: EdgeInsets.all(20),
              child: Row(
                children: [
                  Requirement(image: "assets/mask.png"),
                  Spacer(),
                  Requirement(image: "assets/detergent.png"),
                  Spacer(),
                  Requirement(image: "assets/sneeze.png"),
                  Spacer(),
                  Requirement(image: "assets/no_hand_shake.png"),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SymptomsCard extends StatelessWidget {
  SymptomsCard({this.name, this.image});

  final String name;
  final String image;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 300,
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(color: Colors.grey[200], blurRadius: 10, spreadRadius: 10),
        ],
      ),
      child: Row(
        children: [
          Container(
            child: Image(
              image: AssetImage(image),
            ),
          ),
          SizedBox(
            width: 20,
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                name,
                style: GoogleFonts.montserrat(
                  fontWeight: FontWeight.w500,
                  fontSize: 16,
                  color: Color(0xff1878F6),
                ),
              ),
              Spacer(),
              SizedBox(
                width: 150,
                child: Text(
                  "Lorem Ipsum is a simply dummy text of the printing",
                  style: GoogleFonts.montserrat(
                    fontWeight: FontWeight.w300,
                    fontSize: 14,
                    color: Color(0xff061035),
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}

class Header extends StatelessWidget {
  Header({this.item1, this.item2});
  final String item1;
  final String item2;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20),
      child: Row(
        children: [
          Text(
            item1,
            style: GoogleFonts.montserrat(
              fontWeight: FontWeight.w700,
              fontSize: 20,
              color: Color(0xff061035),
            ),
          ),
          Spacer(),
          Text(
            item2,
            style: GoogleFonts.montserrat(
              fontWeight: FontWeight.w400,
              fontSize: 15,
              color: Color(0xffB4B4B4),
            ),
          )
        ],
      ),
    );
  }
}

class Requirement extends StatelessWidget {
  Requirement({this.image});
  final String image;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.white,
        boxShadow: [
          BoxShadow(color: Colors.grey[200], blurRadius: 7, spreadRadius: 7),
        ],
      ),
      child: Image(
        image: AssetImage(image),
      ),
    );
  }
}
